var firebaseReference = firebase.database().ref();

var article = document.createElement("article");
var paragraph = document.createElement("p");
var text = document.createTextNode(submitClick());
article.appendChild(paragraph).appendChild(text);


var para = document.createElement("p");
var node = document.createTextNode("This is new.");
para.appendChild(node);
var element = document.getElementById("demoArticle");
element.appendChild(para);



/*function displayArticle() {
    article.innerHTML = article(createArticle);
}*/
