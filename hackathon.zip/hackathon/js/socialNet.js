var firebaseReference = firebase.database().ref();

var title = document.getElementById("title");
var content = document.getElementById("content");
var submit = document.getElementById("submit");

var newPostKey;
function submitClick(){
        newPostKey = firebaseReference.child('posts').push().key;
        var postTitle = title.value;
        var postContent = content.value;
        firebaseReference.child(newPostKey).child("Title").set(postTitle);
        firebaseReference.child(newPostKey).child("Content").set(postContent);
        location.reload(); 
}

/*function createArticle(){
    document.getElementById("submit").addEventListener("click", function(){submitClick()});
}*/